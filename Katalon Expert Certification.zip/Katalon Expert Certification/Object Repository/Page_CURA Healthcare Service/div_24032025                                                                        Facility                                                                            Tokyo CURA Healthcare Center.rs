<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_24032025                                                                        Facility                                                                            Tokyo CURA Healthcare Center</name>
   <tag></tag>
   <elementGuidId>f7562c0d-999e-43c3-9b3e-dd3c85d785cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.col-sm-offset-2.col-sm-8</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='history']/div/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;24/03/2025 Facility Tokyo CURA Healthcare Center Apply for hospital readmission &quot;i >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b29e12ff-b02f-42f9-aebb-377a76aaa451</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> col-sm-offset-2 col-sm-8</value>
      <webElementGuid>8f95b08b-36a6-4aec-9c37-e31e15a27c43</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    24/03/2025
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            </value>
      <webElementGuid>e4631c82-b733-4c62-a24a-aa12cc214ca9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-offset-2 col-sm-8&quot;]</value>
      <webElementGuid>129fd618-9297-441f-975e-ccb3b5fce7d4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='history']/div/div[2]/div</value>
      <webElementGuid>da066b2d-615c-4d2c-b933-3124924d2be2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='History'])[2]/following::div[2]</value>
      <webElementGuid>6d38f5df-141a-4fc4-80e6-19ff40c3f3c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Make Appointment'])[1]/following::div[5]</value>
      <webElementGuid>6e133587-d557-437f-9aa1-c5968e96e5b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div</value>
      <webElementGuid>709be6f5-265d-4a2c-a60c-5d679c012cb4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    24/03/2025
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            ' or . = '
                
                    24/03/2025
                    
                        
                            Facility
                        
                        
                            Tokyo CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            No
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicare
                        
                        

                        
                            Comment
                        
                        
                            
                        
                    
                
            ')]</value>
      <webElementGuid>f7c54f94-f6ed-4db2-900a-918d92a57999</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
