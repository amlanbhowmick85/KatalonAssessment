<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>nav_CURA Healthcare                            Home                                    Login</name>
   <tag></tag>
   <elementGuidId>435a3b7f-07e8-446c-9e00-c53f8b9824f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#sidebar-wrapper</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='sidebar-wrapper']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#sidebar-wrapper</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>nav</value>
      <webElementGuid>b0348fea-c924-42a2-8235-b67fda2bae37</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>sidebar-wrapper</value>
      <webElementGuid>6be024b5-1ad3-437a-beec-5ff1c077678b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>active</value>
      <webElementGuid>de7d3965-ca8b-4fc8-85ce-c0a336f0806a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            
</value>
      <webElementGuid>48e3a9c0-ef00-42a0-bc30-1414bfbcd38c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar-wrapper&quot;)</value>
      <webElementGuid>2e652bcc-344b-45e1-b70d-1c015f60d043</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//nav[@id='sidebar-wrapper']</value>
      <webElementGuid>70bfa0ff-57f1-4a63-885d-fa388003cb1a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//nav</value>
      <webElementGuid>ab78cebe-0b54-4ec6-a232-ffebde061f57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//nav[@id = 'sidebar-wrapper' and (text() = '
    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            
' or . = '
    
        
        
            CURA Healthcare
        
        
            Home
        
                
            Login
        
            
')]</value>
      <webElementGuid>36214d1f-c211-4b38-9c77-d8d31fffe54f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
